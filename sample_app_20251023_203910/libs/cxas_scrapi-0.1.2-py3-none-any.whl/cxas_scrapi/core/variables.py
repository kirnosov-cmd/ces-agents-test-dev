# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Core Variables class for CXAS Scrapi."""

import logging
from typing import Dict, List, Optional, Any
from google.cloud.ces_v1beta import types

from cxas_scrapi.core.apps import Apps


class Variables(Apps):
    """Core Class for managing Variables (App Resources)."""

    def __init__(
        self,
        app_id: str,
        creds_path: str = None,
        creds_dict: Dict[str, str] = None,
        creds: Any = None,
        scope: List[str] = None,
    ):
        """Initializes the Variables client.
        Note that Variables are resources of the App itself, not a standalone resource.
        This class is a wrapper around the App class to make it easier to manage Variables.
        """
        project_id = app_id.split("/")[1]
        location = app_id.split("/")[3]

        super().__init__(
            project_id=project_id,
            location=location,
            creds_path=creds_path,
            creds_dict=creds_dict,
            creds=creds,
            scope=scope,
        )
        self.app_id = app_id
        self.resource_type = "variables"

    @staticmethod
    def _check_schema_type(input_type: str):
        # these are the only valid types mapping to types.App.VariableDeclaration.Schema.Type
        if input_type.upper() not in [
            "STRING",
            "INTEGER",
            "NUMBER",
            "BOOLEAN",
            "OBJECT",
            "ARRAY",
        ]:
            raise ValueError(f"Invalid schema type: {input_type}")

    def list_variables(self, app_id: str) -> List[Any]:
        """Lists variables within a specific app."""
        app = self.get_app(app_id)
        return list(app.variable_declarations)

    def get_variable(self, app_id: str, variable_name: str) -> Optional[Any]:
        """Gets a specific variable by its name within a specified app."""
        vars_list = self.list_variables(app_id)

        for var in vars_list:
            if var.name == variable_name:
                return var

        return None

    def create_variable(
        self,
        app_id: str,
        variable_name: str,
        variable_type: str,
        variable_value: Optional[Any],
    ) -> None:
        """Creates a new variable within a specified app."""
        self._check_schema_type(variable_type)
        app = self.get_app(app_id)
        vars_list = list(app.variable_declarations)

        for var in vars_list:
            if var.name == variable_name:
                logging.warning(f"Variable '{variable_name}' already exists.")
                return

        new_var = types.App.VariableDeclaration(
            name=variable_name,
            schema={"type_": variable_type.upper(), "default": variable_value},
        )

        vars_list.append(new_var)
        self.update_app(app_id, variable_declarations=vars_list)
        logging.info(f"Variable '{variable_name}' created successfully.")

    def update_variable(
        self,
        app_id: str,
        variable_name: str,
        variable_type: str,
        variable_value: Optional[Any],
    ) -> None:
        """Updates a variable within a specific app.

        Acceptable types: STRING, INTEGER, NUMBER, BOOLEAN, ARRAY, OBJECT
        """
        self._check_schema_type(variable_type)
        app = self.get_app(app_id)
        vars_list = list(app.variable_declarations)

        updated = False
        for i, var in enumerate(vars_list):
            if var.name == variable_name:
                var.schema.type_ = getattr(
                    types.App.VariableDeclaration.Schema.Type, variable_type.upper()
                )
                var.schema.default = variable_value
                updated = True
                break

        if not updated:
            new_var = types.App.VariableDeclaration(
                name=variable_name,
                schema={"type_": variable_type.upper(), "default": variable_value},
            )
            vars_list.append(new_var)

        self.update_app(app_id, variable_declarations=vars_list)
        logging.info(f"Variable '{variable_name}' set successfully.")

    def delete_variable(self, app_id: str, variable_name: str) -> None:
        """Deletes a specific variable within a specified app."""
        app = self.get_app(app_id)
        vars_list = list(app.variable_declarations)

        original_len = len(vars_list)
        vars_list = [v for v in vars_list if v.name != variable_name]

        if len(vars_list) < original_len:
            self.update_app(app_id, variable_declarations=vars_list)
            logging.info(f"Variable '{variable_name}' deleted successfully.")
        else:
            logging.warning(f"Variable '{variable_name}' not found.")
