"""Templates used by the CXAS SCRAPI CLI."""

GITHUB_ACTION_TEMPLATE_TEST = """name: "CI Test {agent_name}"

on:
  pull_request:
    paths:
      - '{path_filter}/*.yaml'
      - '{path_filter}/*.json'

env:
  PROJECT_ID: "{project_id}"
  LOCATION: "{location}"
{auth_env}

jobs:
  test-{agent_name_lower}:
    runs-on: ubuntu-latest

    permissions:
      contents: 'read'
      id-token: 'write'

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

{auth_step}

      - name: Set up Cloud SDK
        uses: google-github-actions/setup-gcloud@v2

      - name: Configure Docker Auth
        run: gcloud auth configure-docker us-central1-docker.pkg.dev


      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: Build Docker Image
        uses: docker/build-push-action@v5
        with:
          context: .
          load: true
          tags: agent-image
          cache-from: type=gha
          cache-to: type=gha,mode=max

      - name: Run CI Test Lifecycle (Docker)
        run: |
          docker run --rm \\
            -v ${{ github.workspace }}:/workspace \\
            -w /workspace \\
            -e PROJECT_ID=${{{{ env.PROJECT_ID }}}} \\
            -e LOCATION=${{{{ env.LOCATION }}}} \\
{docker_auth_args}
            agent-image \\
            ci-test --agent_dir {agent_dir} \\
                      --project_id ${{{{ env.PROJECT_ID }}}} \\
                      --location ${{{{ env.LOCATION }}}} \\
                      --display_name "[CI] PR-${{{{ github.event.pull_request.number }}}} {agent_name}"

"""

GITHUB_ACTION_TEMPLATE_DEPLOY = """name: "Deploy {agent_name}"

on:
  push:
    branches:
      - main
      - master
    paths:
      - '{path_filter}/*.yaml'
      - '{path_filter}/*.json'

env:
  PROJECT_ID: "{project_id}"
  LOCATION: "{location}"
  APP_ID: "{app_id}"
  DISPLAY_NAME: "{agent_name}"
{auth_env}

jobs:
  deploy-{agent_name_lower}:
    runs-on: ubuntu-latest

    permissions:
      contents: 'read'
      id-token: 'write'

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'

{auth_step}

      - name: Set up Cloud SDK
        uses: google-github-actions/setup-gcloud@v2

      - name: Install cxas-scrapi CLI
        run: |
          python -m pip install --upgrade pip
          wget https://storage.googleapis.com/gassets-api-ai/ces-client-libraries/v1beta/ces-v1beta-py.tar
          pip install ces-v1beta-py.tar --quiet
          gsutil cp gs://cxas-scrapi/dist/cxas_scrapi-0.1.0-py3-none-any.whl .
          pip install cxas_scrapi-0.1.0-py3-none-any.whl

      - name: Deploy to CX Agent Studio
        run: |
          cxas-eval deploy --agent_dir {agent_dir} \\
                           --project_id ${{{{ env.PROJECT_ID }}}} \\
                           --location ${{{{ env.LOCATION }}}} \\
                           --app_id ${{{{ env.APP_ID }}}} \\
                           --display_name "${{{{ env.DISPLAY_NAME }}}}"
"""

GITHUB_ACTION_TEMPLATE_CLEANUP = """name: "Cleanup {agent_name}"

on:
  pull_request:
    types: [closed]
    paths:
      - '{path_filter}/*.yaml'
      - '{path_filter}/*.json'

env:
  PROJECT_ID: "{project_id}"
  LOCATION: "{location}"
{auth_env}

jobs:
  cleanup-{agent_name_lower}:
    runs-on: ubuntu-latest
    if: github.event.pull_request.merged == true || github.event.pull_request.closed == true

    permissions:
      contents: 'read'
      id-token: 'write'

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'

{auth_step}

      - name: Set up Cloud SDK
        uses: google-github-actions/setup-gcloud@v2

      - name: Install cxas-scrapi CLI
        run: |
          python -m pip install --upgrade pip
          wget https://storage.googleapis.com/gassets-api-ai/ces-client-libraries/v1beta/ces-v1beta-py.tar
          pip install ces-v1beta-py.tar --quiet
          pip install cxas-scrapi

      - name: Run Cleanup
        run: |
          cxas-eval delete --display_name "[CI] PR-${{{{ github.event.pull_request.number }}}} {agent_name}" \\
                   --project_id ${{{{ env.PROJECT_ID }}}} \\
                   --location ${{{{ env.LOCATION }}}}
"""



DOCKERFILE_TEMPLATE = """# Use an official Python runtime as a parent image
FROM python:3.11-slim


# Set the working directory to /app
WORKDIR /app

# Install git and wget (required for pip install git+... and downloading CES lib)
RUN apt-get update && apt-get install -y git wget && rm -rf /var/lib/apt/lists/*

# Install CES Client Library (Pre-requisite) - Cached Layer
RUN wget https://storage.googleapis.com/gassets-api-ai/ces-client-libraries/v1beta/ces-v1beta-py.tar && \\
    pip install ces-v1beta-py.tar --quiet && \\
    rm ces-v1beta-py.tar

# Copy requirements first to leverage Docker cache
COPY requirements.txt .

# Install dependencies - Cached Layer
RUN pip install --no-cache-dir -r requirements.txt

# Copy the agent code into the container
COPY . .

# Set the entrypoint to cxas-scrapi
ENTRYPOINT ["cxas-eval"]
"""
