# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Utility functions for processing and exporting CXAS Evaluation Results."""

from typing import Annotated, Any, Dict, List, Optional, NamedTuple, Union
import datetime
import time
import enum
import io
import json
import logging
import pprint
import uuid
import zipfile

import pandas as pd
import yaml
import pandas_gbq
from google.cloud.ces_v1beta import types
from google.cloud import bigquery
from google.protobuf.json_format import MessageToDict
from jsonpath_ng import parse
from proto.marshal.collections import maps, repeated
from pydantic import (
    AliasChoices,
    AliasPath,
    BaseModel,
    BeforeValidator,
    Field,
    TypeAdapter,
)
from sentence_transformers import SentenceTransformer, util
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed

from cxas_scrapi.core.apps import Apps
from cxas_scrapi.core.agents import Agents
from cxas_scrapi.core.conversation_history import ConversationHistory
from cxas_scrapi.core.evaluations import Evaluations
from cxas_scrapi.core.sessions import Sessions
from cxas_scrapi.core.tools import Tools
from cxas_scrapi.core.variables import Variables
from cxas_scrapi.utils.latency_parser import LatencyParser

logger = logging.getLogger(__name__)

SUMMARY_SCHEMA_COLUMNS = [
    "test_run_timestamp",
    "test_type",
    "total_tests",
    "pass_count",
    "pass_rate",
    "p50_latency_ms",
    "p90_latency_ms",
    "p99_latency_ms",
    "agent_name",
    "model",
]


class SummaryStats(NamedTuple):
    pass_count: int
    pass_rate: float
    total_tests: int
    p50_latency_ms: float
    p90_latency_ms: float
    p99_latency_ms: float
    agent_name: str
    model: str


class EvalUtils(Evaluations):
    def __init__(self, app_id: str, env: str = "PROD"):
        """Initializes the EvalUtils class for processing Evaluation Results.

        Args:
            app_id: CXAS App ID (projects/{project}/locations/{location}/apps/{app}).
            env: Environment override (default: PROD).
        """
        super().__init__(app_id=app_id, env=env)
        self.app_id = app_id
        self.tools_client = Tools(app_id=self.app_id, creds=self.creds)
        self.var_client = Variables(app_id=self.app_id, creds=self.creds)
        try:
            self.tool_map = self.tools_client.get_tools_map(self.app_id, reverse=True)
        except Exception as e:
            logger.warning(f"Failed to fetch tool map for {self.app_id}: {e}")
            self.tool_map = {}
        self.agents_client = Agents(app_id=self.app_id, creds=self.creds)
        self.ch_client = ConversationHistory(app_id=self.app_id, creds=self.creds)

    @staticmethod
    def parse_variables_input(v: Any) -> Dict[str, Any]:
        """Allows YAML to accept a list of strings OR a custom dictionary."""
        if v is None:
            return {}
        if isinstance(v, str):
            try:
                return json.loads(v)
            except Exception:
                return {}
        if isinstance(v, list):
            # Convert list of names to a dict flagged for fetching (None)
            return {str(item): None for item in v}
        if isinstance(v, dict):
            return v
        return {}

    @staticmethod
    def empty_to_dict(v: Any) -> Any:
        return v if v is not None else {}

    @staticmethod
    def empty_to_list(v: Any) -> Any:
        return v if v is not None else []

    @staticmethod
    def _calculate_stats(df: pd.DataFrame) -> SummaryStats:
        """Calculates summary statistics from a test results DataFrame."""
        total_tests = len(df)
        if total_tests == 0:
            return SummaryStats(0, 0.0, 0, 0.0, 0.0, 0.0, "Unknown", "Unknown")

        pass_count = sum(1 for p in df.get("pass", []) if p is True)
        pass_rate = round(pass_count / total_tests, 2) if total_tests > 0 else 0.0

        has_latency = (
            "latency (ms)" in df.columns
            and not df.empty
            and not df["latency (ms)"].dropna().empty
        )
        p50 = (
            round(df["latency (ms)"].dropna().quantile(0.50), 2) if has_latency else 0.0
        )
        p90 = (
            round(df["latency (ms)"].dropna().quantile(0.90), 2) if has_latency else 0.0
        )
        p99 = (
            round(df["latency (ms)"].dropna().quantile(0.99), 2) if has_latency else 0.0
        )

        agent_name = (
            df["app_display_name"].iloc[0]
            if "app_display_name" in df.columns and not df.empty
            else "Unknown"
        )
        model = (
            df["model"].iloc[0] if "model" in df.columns and not df.empty else "Unknown"
        )

        return SummaryStats(
            pass_count=pass_count,
            pass_rate=pass_rate,
            total_tests=total_tests,
            p50_latency_ms=p50,
            p90_latency_ms=p90,
            p99_latency_ms=p99,
            agent_name=agent_name,
            model=model,
        )

    @staticmethod
    def _map_outcome(val):
        if isinstance(val, int):
            return {0: "UNSPECIFIED", 1: "PASS", 2: "FAIL"}.get(val, f"UNKNOWN_{val}")
        return str(val) if val is not None else None

    @staticmethod
    def compute_semantic_similarity(
        text1: str, text2: str, model_name: str = "all-MiniLM-L6-v2"
    ) -> float:
        """Computes basic embedding-based semantic similarity between two strings.

        This uses the local 'sentence-transformers' library rather than an LLM.
        The default model ('all-MiniLM-L6-v2') is small, fast, and effective.

        Args:
            text1: The first string to compare.
            text2: The second string to compare.
            model_name: The sentence-transformers model to use.

        Returns:
            A float between -1.0 and 1.0 representing the cosine similarity.
        """
        # Load the local embedding model (downloads automatically on first run)
        model = SentenceTransformer(model_name)

        # Generate embeddings
        emb1 = model.encode(text1, convert_to_tensor=True)
        emb2 = model.encode(text2, convert_to_tensor=True)

        # Compute cosine similarity
        cosine_score = util.cos_sim(emb1, emb2).item()
        return cosine_score

    @staticmethod
    def variable_to_dict(variable: Any) -> Any:
        """Converts a VariableDeclaration object or other types to a dictionary/value."""

        # 1. Handle RepeatedComposite (List)
        if isinstance(variable, repeated.RepeatedComposite):
            return [EvalUtils.variable_to_dict(v) for v in variable]

        # 2. Handle MapComposite (Dict)
        if isinstance(variable, maps.MapComposite):
            return {k: EvalUtils.variable_to_dict(v) for k, v in variable.items()}

        # 3. If it's already a dict or primitive, return as is
        if isinstance(variable, (dict, list, str, int, float, bool, type(None))):
            return variable

        # 4. Priority: Check for schema.default (VariableDeclaration pattern)
        try:
            if hasattr(variable, "schema") and hasattr(variable.schema, "default"):
                return EvalUtils.variable_to_dict(variable.schema.default)
        except Exception:
            pass

        # 5. Check if it has a to_dict method (common in Google Protobufs)
        if hasattr(variable, "to_dict"):
            return variable.to_dict()

        # 6. Check if it has a to_dict method on the type
        if hasattr(type(variable), "to_dict"):
            return type(variable).to_dict(variable)

        return variable

    def _parse_eval_results(
        self,
        results: Optional[Union[List[Any], str]] = None,
        eval_names: Optional[Union[List[str], str]] = None,
    ) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
        if isinstance(results, str):
            eval_names = [results]
            results = None
        elif (
            isinstance(results, list)
            and len(results) > 0
            and isinstance(results[0], str)
        ):
            eval_names = results
            results = None

        if isinstance(eval_names, str):
            eval_names = [eval_names]

        if results is None:
            results = []
            evaluations = self.list_evaluations(self.app_id)
            for evaluation in evaluations:
                if (
                    eval_names
                    and evaluation.display_name not in eval_names
                    and evaluation.name not in eval_names
                ):
                    continue
                results.extend(self.list_evaluation_results(evaluation.name))

        run_summaries = []
        expectations = []
        turns = []
        eval_cache = {}

        for result in results:
            res_dict = type(result).to_dict(result)
            result_name = res_dict.get("name", "")
            eval_name = "/".join(result_name.split("/")[:-2])
            display_name = "Unknown Evaluation"
            if eval_name:
                if eval_name not in eval_cache:
                    try:
                        eval_obj = self.get_evaluation(eval_name)
                        eval_cache[eval_name] = eval_obj.display_name
                    except Exception:
                        eval_cache[eval_name] = "Unknown Evaluation"
                display_name = eval_cache[eval_name]

            raw_status = res_dict.get("evaluation_status", 0)
            if isinstance(raw_status, int):
                status_map = {0: "UNSPECIFIED", 1: "✅ PASSED", 2: "❌ FAILED"}
                status_str = status_map.get(raw_status, f"UNKNOWN_{raw_status}")
            else:
                status_str = str(raw_status)

            golden = res_dict.get("golden_result", {})
            metrics = golden.get("metrics", {}) if golden else {}

            sem_score_raw = metrics.get("semantic_similarity_result", {}).get("score")
            sem_score_str = (
                f"{int(sem_score_raw) if sem_score_raw == int(sem_score_raw) else sem_score_raw} / 4.0"
                if isinstance(sem_score_raw, (int, float))
                else str(sem_score_raw) if sem_score_raw is not None else None
            )

            tool_score_raw = metrics.get("overall_tool_invocation_result", {}).get(
                "tool_invocation_score"
            )
            tool_score_str = (
                f"{int(tool_score_raw * 100)}%"
                if isinstance(tool_score_raw, (int, float))
                else EvalUtils._map_outcome(tool_score_raw)
            )

            base_info = {
                "display_name": display_name,
                "eval_result_id": result_name,
                "evaluation_status": status_str,
                "semantic_score": sem_score_str,
                "tool_invocation_score": tool_score_str,
                "create_time": res_dict.get("create_time", ""),
                "update_time": res_dict.get("update_time", ""),
            }
            run_summaries.append(base_info)

            expectation_list = metrics.get("expectation_results", [])
            for exp_item in expectation_list:
                row = {
                    "display_name": display_name,
                    "eval_result_id": result_name,
                    "record_type": "summary_expectation",
                    "expectation": str(exp_item.get("expectation", "")),
                    "met_count": exp_item.get("met_count", 0),
                    "not_met_count": exp_item.get("not_met_count", 0),
                    "met_percentage": exp_item.get("met_percentage", 0.0),
                    "not_met_percentage": exp_item.get("not_met_percentage", 0.0),
                }
                expectations.append(row)

            turn_list = golden.get("turn_replay_results", [])
            if isinstance(turn_list, list):
                for i, turn in enumerate(turn_list):
                    if not isinstance(turn, dict):
                        continue
                    row = {
                        "display_name": display_name,
                        "eval_result_id": result_name,
                        "turn_index": i + 1,
                    }
                    lat = turn.get("turn_latency", {})
                    row["latency_seconds"] = (
                        lat.get("seconds", 0) if isinstance(lat, dict) else None
                    )

                    sem_res = turn.get("semantic_similarity_result", {})
                    if isinstance(sem_res, dict):
                        row["semantic_score"] = sem_res.get("score")
                        row["semantic_outcome"] = EvalUtils._map_outcome(
                            sem_res.get("outcome")
                        )
                    else:
                        row["semantic_score"] = None
                        row["semantic_outcome"] = None

                    hal_res = turn.get("hallucination_result", {})
                    row["hallucination_score"] = (
                        hal_res.get("score") if isinstance(hal_res, dict) else None
                    )
                    row["hallucination"] = (
                        hal_res.get("label", "") if isinstance(hal_res, dict) else None
                    )

                    row["tool_invocation_score"] = EvalUtils._map_outcome(
                        turn.get("tool_invocation_score")
                    )

                    outcomes = turn.get("expectation_outcome", [])
                    row["expectation_outcomes"] = json.dumps(outcomes)

                    turns.append(row)

        return run_summaries, expectations, turns

    def _get_value_at_path(self, data: Any, path: str) -> Any:
        """Retrieves value from data using dot notation (e.g., 'a.b.c' or 'list.0.item')."""
        jsonpath_expression = parse(path)
        matches = jsonpath_expression.find(data)
        if matches:
            return [m.value for m in matches] if len(matches) > 1 else matches[0].value
        return None

    def _check_expectation(self, actual: Any, expectation: "Expectation") -> bool:
        """Checks if actual value meets the expectation."""
        op = expectation.operator
        expected = expectation.value

        if op == Operator.EQUALS:
            return actual == expected
        elif op == Operator.CONTAINS:
            if isinstance(actual, (str, list, dict)):
                return expected in actual
            return False
        elif op == Operator.GREATER_THAN:
            try:
                return actual > expected
            except TypeError:
                return False
        elif op == Operator.LESS_THAN:
            try:
                return actual < expected
            except TypeError:
                return False
        elif op == Operator.LENGTH_EQUALS:
            try:
                return len(actual) == expected
            except TypeError:
                return False
        elif op == Operator.LENGTH_GREATER_THAN:
            try:
                return len(actual) > expected
            except TypeError:
                return False
        elif op == Operator.LENGTH_LESS_THAN:
            try:
                return len(actual) < expected
            except TypeError:
                return False
        elif op == Operator.IS_NULL:
            return actual is None
        elif op == Operator.IS_NOT_NULL:
            return actual is not None
        return False

    def _search_span_dict(self, span_dict: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        # Sometimes span names can be upper/lower cased.
        if span_dict.get("name", "").lower() == "guardrail":
            attrs = span_dict.get("attributes", {})
            if (
                str(attrs.get("triggered", "")).lower() == "true"
                or attrs.get("triggered") is True
            ):
                return span_dict

        child_spans = span_dict.get("childSpans", span_dict.get("child_spans", []))
        for child in child_spans:
            res = self._search_span_dict(child)
            if res:
                return res
        return None

    def generate_report(
        self, df: pd.DataFrame, test_type: str = "guardrails_test"
    ) -> pd.DataFrame:
        """Generates a summary stats report for recent tests."""
        report_timestamp = datetime.datetime.now()
        stats = EvalUtils._calculate_stats(df)

        df_report = pd.DataFrame(
            columns=SUMMARY_SCHEMA_COLUMNS,
            data=[
                [
                    report_timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                    test_type,
                    stats.total_tests,
                    stats.pass_count,
                    stats.pass_rate,
                    stats.p50_latency_ms,
                    stats.p90_latency_ms,
                    stats.p99_latency_ms,
                    stats.agent_name,
                    stats.model,
                ]
            ],
        )

        return df_report

    def evals_to_dataframe(
        self,
        results: Optional[Union[List[Any], str]] = None,
        eval_names: Optional[Union[List[str], str]] = None,
    ) -> Dict[str, Any]:
        """Provides three simplified views of the evaluation data.

        Returns:
            A dict with 'summary', 'failures', and 'trace' DataFrames.
        """
        run_summaries, expectations, turns = self._parse_eval_results(
            results, eval_names
        )

        # Summary
        df_summary = pd.DataFrame(run_summaries)
        if not df_summary.empty:
            if "create_time" in df_summary.columns:
                df_summary["create_time"] = pd.to_datetime(df_summary["create_time"])
            if "update_time" in df_summary.columns:
                df_summary["update_time"] = pd.to_datetime(df_summary["update_time"])
            if "update_time" in df_summary.columns:
                df_summary = df_summary.sort_values(
                    by="update_time", ascending=False
                ).reset_index(drop=True)

        # Failures
        failures = []
        for exp in expectations:
            if exp.get("not_met_count", 0) > 0:
                failures.append(
                    {
                        "display_name": exp["display_name"],
                        "eval_result_id": exp["eval_result_id"],
                        "turn_index": None,
                        "failure_type": "Expectation",
                        "expected": str(exp.get("expectation", "")),
                        "actual": "(Not Met)",
                        "score": None,
                    }
                )

        for turn in turns:
            outcomes_str = turn.get("expectation_outcomes", "[]")
            outcomes = []
            try:
                outcomes = json.loads(outcomes_str)
            except Exception:
                pass

            def _get_exp_act(outcome_obj):
                e_text = ""
                a_text = "(None / Missed)"
                f_type = "Turn Expectation"
                e_dict = outcome_obj.get("expectation", {})

                if "agent_response" in e_dict:
                    chunks = e_dict["agent_response"].get("chunks", [])
                    e_text = (
                        chunks[0].get("text", "agent_response")
                        if chunks
                        else "agent_response"
                    )
                    f_type = "Semantic Similarity"
                elif "tool_call" in e_dict:
                    e_text = e_dict["tool_call"].get(
                        "display_name", e_dict["tool_call"].get("id", "tool_call")
                    )
                    f_type = "Tool Call"
                elif "agent_transfer" in e_dict:
                    e_text = e_dict["agent_transfer"].get(
                        "display_name",
                        e_dict["agent_transfer"].get("target_agent", "agent_transfer"),
                    )
                    f_type = "Routing / Agent"

                if "observed_agent_response" in outcome_obj:
                    chunks = outcome_obj["observed_agent_response"].get("chunks", [])
                    a_text = chunks[0].get("text", "") if chunks else ""
                elif "observed_tool_call" in outcome_obj:
                    a_text = outcome_obj["observed_tool_call"].get(
                        "display_name", outcome_obj["observed_tool_call"].get("id", "")
                    )
                elif "observed_agent_transfer" in outcome_obj:
                    a_text = outcome_obj["observed_agent_transfer"].get(
                        "display_name",
                        outcome_obj["observed_agent_transfer"].get("target_agent", ""),
                    )

                return e_text, a_text, f_type

            sem_handled = False
            tool_handled = False

            # Process individual explicit expectation failures
            for outcome_obj in outcomes:
                raw_outcome = outcome_obj.get("outcome")
                if raw_outcome == 2 or EvalUtils._map_outcome(raw_outcome) == "FAIL":
                    e, a, f = _get_exp_act(outcome_obj)
                    score_val = None
                    if f == "Semantic Similarity":
                        raw_score = turn.get("semantic_score")
                        if isinstance(raw_score, (int, float)):
                            score_val = f"{int(raw_score) if raw_score == int(raw_score) else raw_score} / 4.0"
                        else:
                            score_val = (
                                str(raw_score) if raw_score is not None else None
                            )
                        sem_handled = True
                    elif f == "Tool Call":
                        raw_score = turn.get("tool_invocation_score")
                        if isinstance(raw_score, (int, float)):
                            score_val = f"{int(raw_score * 100)}%"
                        else:
                            score_val = EvalUtils._map_outcome(raw_score)

                        if EvalUtils._map_outcome(raw_score) == "FAIL":
                            tool_handled = True

                    failures.append(
                        {
                            "display_name": turn["display_name"],
                            "eval_result_id": turn["eval_result_id"],
                            "turn_index": turn["turn_index"],
                            "failure_type": f,
                            "expected": e,
                            "actual": a,
                            "score": score_val,
                        }
                    )

            # Process overall semantic failure if not caught
            sem_outcome = turn.get("semantic_outcome")
            if sem_outcome == "FAIL" and not sem_handled:
                e_text, a_text = "", ""
                for outcome_obj in outcomes:
                    if "agent_response" in outcome_obj.get("expectation", {}):
                        e_text, a_text, _ = _get_exp_act(outcome_obj)
                        break
                raw_score = turn.get("semantic_score")
                if isinstance(raw_score, (int, float)):
                    score_val = f"{int(raw_score) if raw_score == int(raw_score) else raw_score} / 4.0"
                else:
                    score_val = str(raw_score) if raw_score is not None else None

                failures.append(
                    {
                        "display_name": turn["display_name"],
                        "eval_result_id": turn["eval_result_id"],
                        "turn_index": turn["turn_index"],
                        "failure_type": "Semantic Similarity",
                        "expected": e_text,
                        "actual": a_text,
                        "score": score_val,
                    }
                )

            # Process overall tool failure if not caught
            tool_outcome = turn.get("tool_invocation_score")
            if tool_outcome == "FAIL" and not tool_handled:
                e_text, a_text = "", ""
                for outcome_obj in outcomes:
                    if "tool_call" in outcome_obj.get("expectation", {}):
                        e_text, a_text, _ = _get_exp_act(outcome_obj)
                        break
                failures.append(
                    {
                        "display_name": turn["display_name"],
                        "eval_result_id": turn["eval_result_id"],
                        "turn_index": turn["turn_index"],
                        "failure_type": "Tool Call",
                        "expected": e_text,
                        "actual": a_text,
                        "score": "FAIL",
                    }
                )

        df_failures = pd.DataFrame(failures)
        if not df_failures.empty:
            df_failures = df_failures.sort_values(
                by=["eval_result_id", "turn_index"]
            ).reset_index(drop=True)

        df_traces = pd.DataFrame(turns)

        return {"summary": df_summary, "failures": df_failures, "trace": df_traces}

    def get_latency_metrics_dfs(
        self,
        results: Optional[List[Any]] = None,
        eval_names: Optional[List[str]] = None,
        app_id: Optional[str] = None,
    ) -> Dict[str, pd.DataFrame]:
        """Generates detailed and aggregated latency metrics DataFrames from evaluation results and traces.

        Args:
            results: An optional list of Eval Result List payload chunks.
            eval_names: Alternatively, an optional list of string Display Names / Names of Evals.
            app_id: Optional override if retrieving Conversation traces dynamically.
        """
        if not results:
            if not getattr(self, "app_id", None) and not app_id:
                raise ValueError("app_id must be set to look up evaluations by name.")
            results = []
            for name in eval_names or []:
                # Retrieve all results for the provided display name
                results.extend(self.list_evaluation_results(name))

        if not results:
            return {
                "eval_summary": pd.DataFrame(),
                "eval_details": pd.DataFrame(),
                "tool_summary": pd.DataFrame(),
                "tool_details": pd.DataFrame(),
                "callback_summary": pd.DataFrame(),
                "callback_details": pd.DataFrame(),
                "guardrail_summary": pd.DataFrame(),
                "guardrail_details": pd.DataFrame(),
            }

        conv_ids = set()
        for res_obj in results:
            res_dict = (
                type(res_obj).to_dict(res_obj)
                if not isinstance(res_obj, dict)
                else res_obj
            )
            turns = res_dict.get("golden_result", {}).get("turn_replay_results", [])
            for t in turns:
                if t.get("conversation"):
                    conv_ids.add(t.get("conversation"))

        target_app = app_id or getattr(self, "app_id", None)
        traces = {}
        if target_app and conv_ids:
            if target_app == getattr(self, "app_id", None):
                ch_getter = self.ch_client.get_conversation
            else:
                ch_client = ConversationHistory(app_id=target_app, creds=self.creds)
                ch_getter = ch_client.get_conversation
            traces = LatencyParser.fetch_conversation_traces(list(conv_ids), ch_getter)

        eval_details_rows = []
        eval_summary_agg = []
        tool_details_rows = []
        callback_details_rows = []
        guardrail_details_rows = []

        for res_obj in results:
            res_dict = (
                type(res_obj).to_dict(res_obj)
                if not isinstance(res_obj, dict)
                else res_obj
            )
            result_name = res_dict.get("name", "")
            tokens = result_name.split("/")
            eval_result_id = tokens[-1] if tokens else result_name
            eval_name = "/".join(tokens[:-2]) if len(tokens) >= 2 else ""

            # Get display name
            display_name = eval_name
            evals_map = getattr(self, "_get_or_load_evals_map", lambda x: {})(
                getattr(self, "app_id", None)
            )
            if evals_map:
                for lookup_name, full_path in evals_map.get("goldens", {}).items():
                    if full_path == eval_name:
                        display_name = lookup_name
                        break
                for lookup_name, full_path in evals_map.get("scenarios", {}).items():
                    if full_path == eval_name:
                        display_name = lookup_name
                        break

            golden = res_dict.get("golden_result", {})
            turns = golden.get("turn_replay_results", [])

            run_total_turn_latencies = []
            run_tool_latencies = []
            run_llm_latencies = []
            run_guardrail_latencies = []
            run_callback_latencies = []

            for turn_idx, t in enumerate(turns):
                total_turn_ms = LatencyParser._parse_duration_ms(
                    t.get("turn_latency", "0s")
                )

                # Turn specific items
                tool_calls = t.get("tool_call_latencies", [])
                turn_tool_ms = sum(
                    [
                        LatencyParser._parse_duration_ms(
                            tc.get("execution_latency", "0s")
                        )
                        for tc in tool_calls
                    ]
                )
                tool_names = ", ".join(
                    [tc.get("display_name", tc.get("tool", "")) for tc in tool_calls]
                )

                turn_llm_ms = 0.0
                turn_guardrail_ms = 0.0
                turn_callback_ms = 0.0

                cid = t.get("conversation")
                if cid and cid in traces:
                    conv = traces[cid]
                    conv_turns = conv.get("turns", [])
                    # Match by index assuming evaluating linearly
                    if turn_idx < len(conv_turns):
                        trace_turn = conv_turns[turn_idx]
                        root = trace_turn.get("root_span", {})
                        if root:
                            sums = LatencyParser._process_spans(
                                [root],
                                eval_result_id,
                                turn_idx + 1,
                                tool_details_rows,
                                callback_details_rows,
                                guardrail_details_rows,
                                context_key="eval_result_id",
                            )
                            turn_llm_ms = sums["LLM"]
                            turn_guardrail_ms = sums["Guardrail"]
                            turn_callback_ms = sums["Callback"]

                run_total_turn_latencies.append(total_turn_ms)
                if turn_tool_ms > 0:
                    run_tool_latencies.append(turn_tool_ms)
                if turn_llm_ms > 0:
                    run_llm_latencies.append(turn_llm_ms)
                if turn_guardrail_ms > 0:
                    run_guardrail_latencies.append(turn_guardrail_ms)
                if turn_callback_ms > 0:
                    run_callback_latencies.append(turn_callback_ms)

                eval_details_rows.append(
                    {
                        "display_name": display_name,
                        "eval_result_id": eval_result_id,
                        "turn_index": turn_idx + 1,
                        "Total Turn Latency (ms)": int(total_turn_ms),
                        "Tool Call Latencies (ms)": int(turn_tool_ms),
                        "LLM Latencies (ms)": int(turn_llm_ms),
                        "Guardrail Latencies (ms)": int(turn_guardrail_ms),
                        "Callback Latencies (ms)": int(turn_callback_ms),
                        "tool_names": tool_names,
                    }
                )

            # Compute run summary aggregations
            def _aggregate(arr):
                if not arr:
                    return {"Average": 0, "p50": 0, "p90": 0, "p99": 0}
                ser = pd.Series(arr)
                return {
                    "Average": int(ser.mean()),
                    "p50": int(ser.quantile(0.50)),
                    "p90": int(ser.quantile(0.90)),
                    "p99": int(ser.quantile(0.99)),
                }

            t_agg = _aggregate(run_total_turn_latencies)
            tc_agg = _aggregate(run_tool_latencies)
            llm_agg = _aggregate(run_llm_latencies)
            gr_agg = _aggregate(run_guardrail_latencies)
            cb_agg = _aggregate(run_callback_latencies)

            eval_summary_agg.append(
                {
                    "display_name": display_name,
                    "eval_result_id": eval_result_id,
                    "evaluation_type": "Golden" if golden else "Scenario",
                    "Average (Turn)": f"{t_agg['Average']} ms",
                    "p50 | p90 | p99 (Turn)": f"{t_agg['p50']} ms | {t_agg['p90']} ms | {t_agg['p99']} ms",
                    "Average (LLM)": f"{llm_agg['Average']} ms",
                    "p50 | p90 | p99 (LLM)": f"{llm_agg['p50']} ms | {llm_agg['p90']} ms | {llm_agg['p99']} ms",
                    "Average (Tool Call)": f"{tc_agg['Average']} ms",
                    "p50 | p90 | p99 (Tool Call)": f"{tc_agg['p50']} ms | {tc_agg['p90']} ms | {tc_agg['p99']} ms",
                    "Average (Guardrail)": f"{gr_agg['Average']} ms",
                    "p50 | p90 | p99 (Guardrail)": f"{gr_agg['p50']} ms | {gr_agg['p90']} ms | {gr_agg['p99']} ms",
                    "Average (Callback)": f"{cb_agg['Average']} ms",
                    "p50 | p90 | p99 (Callback)": f"{cb_agg['p50']} ms | {cb_agg['p90']} ms | {cb_agg['p99']} ms",
                }
            )

        eval_details = pd.DataFrame(eval_details_rows)
        eval_summary = pd.DataFrame(eval_summary_agg)

        tool_details = pd.DataFrame(tool_details_rows)
        callback_details = pd.DataFrame(callback_details_rows)
        guardrail_details = pd.DataFrame(guardrail_details_rows)

        tool_summary = LatencyParser.build_summary_df(tool_details, ["tool_name"])
        callback_summary = LatencyParser.build_summary_df(
            callback_details, ["agent", "stage", "description"]
        )
        guardrail_summary = LatencyParser.build_summary_df(
            guardrail_details, ["agent", "name"]
        )

        return {
            "eval_summary": eval_summary,
            "eval_details": eval_details,
            "tool_summary": tool_summary,
            "tool_details": tool_details,
            "callback_summary": callback_summary,
            "callback_details": callback_details,
            "guardrail_summary": guardrail_summary,
            "guardrail_details": guardrail_details,
        }

    def to_bigquery(
        self,
        df: Any,
        dataset_table: str,
        project_id: Optional[str] = None,
        if_exists: str = "append",
    ):
        """Exports a pandas DataFrame to a Google BigQuery table."""
        target_project = project_id or self._get_project_id(self.app_id)
        df.to_gbq(
            destination_table=dataset_table,
            project_id=target_project,
            if_exists=if_exists,
            credentials=self.creds,
        )
        print(
            f"Successfully uploaded {len(df)} rows to {target_project}.{dataset_table}"
        )

    def load_tool_test_cases_from_file(self, test_file_path: str) -> List["TestCase"]:
        """Loads tool tests from a YAML file."""
        with open(test_file_path, "r") as f:
            return self.load_tool_test_cases_from_yaml(f.read())

    def load_tool_test_cases_from_yaml(self, yaml_data: str) -> List["TestCase"]:
        """Loads tool tests from a YAML string."""
        raw_data = yaml.safe_load(yaml_data)
        if not raw_data or "tests" not in raw_data:
            return []

        return self.load_tool_test_cases_from_data(raw_data["tests"])

    def load_tool_test_cases_from_data(
        self, test_data: List[Dict[str, Any]]
    ) -> List["TestCase"]:
        """Loads tool tests from a list of dictionaries."""
        # Pre-process data to handle VariableDeclaration objects
        cleaned_data = []
        for case in test_data:
            case_copy = case.copy()
            if "variables" in case_copy and isinstance(case_copy["variables"], dict):
                cleaned_vars = {}
                for k, v in case_copy["variables"].items():
                    cleaned_vars[k] = self.variable_to_dict(v)
                case_copy["variables"] = cleaned_vars
            cleaned_data.append(case_copy)

        adapter = TypeAdapter(List[ToolTestCase])
        return adapter.validate_python(cleaned_data)

    def validate_tool_test(
        self,
        test_case: "TestCase",
        tool_response: Any,
    ) -> List[str]:
        """Validates the tool response and variables against expectations.

        Returns:
            List of error messages. Empty list if all expectations pass.
        """
        updated_variables = {}
        if isinstance(tool_response, dict) and "variables" in tool_response:
            updated_variables = tool_response["variables"]

        errors = []
        # Validate response
        for exp in test_case.response_expectations:
            resp_data = (
                tool_response.get("response")
                if isinstance(tool_response, dict)
                else tool_response
            )
            actual_value = self._get_value_at_path(resp_data, exp.path)
            if not self._check_expectation(actual_value, exp):
                errors.append(
                    f"Response expectation failed: path='{exp.path}',"
                    f" actual='{actual_value}', expected='{exp.value}',"
                    f" operator='{exp.operator}'"
                )

        # Validate variables
        for exp in test_case.variable_expectations:
            actual_value = self._get_value_at_path(updated_variables, exp.path)
            if not self._check_expectation(actual_value, exp):
                errors.append(
                    f"Variable expectation failed: path='{exp.path}',"
                    f" actual='{actual_value}', expected='{exp.value}',"
                    f" operator='{exp.operator}'"
                )

        return errors

    def run_tool_tests(self, test_cases: List["TestCase"], debug: bool = False) -> Any:
        """Runs a list of tool tests.

        Returns:
            A list of results (dicts) with status and errors.
        """
        # Fetch and unwrap app variables once
        raw_app_vars = self.var_client.list_variables(self.app_id)
        app_vars_cache = {}
        for var in raw_app_vars:
            try:
                var_dict = MessageToDict(var._pb)
            except AttributeError:
                var_dict = MessageToDict(var)

            schema = var_dict.get("schema", {})
            actual_data = schema.get("default") or var_dict.get("value") or {}
            app_vars_cache[var.name] = actual_data

        results = []
        for test_case in test_cases:
            print(f"Running test: {test_case.name} ({test_case.tool})")

            tool_id = self.tool_map.get(test_case.tool)
            if not tool_id:
                error = f"Tool '{test_case.tool}' not found in app."
                print(f"FAILURE: {error}")
                results.append(
                    {
                        "test": test_case.name,
                        "tool": test_case.tool,
                        "status": "FAILURE",
                        "errors": [error],
                    }
                )
                continue

            # 3. Filter and merge variables for this specific test case
            final_variables = {}
            for var_name, custom_val in test_case.variables.items():
                if custom_val is None:
                    # User requested an existing app variable by name
                    if var_name in app_vars_cache:
                        final_variables[var_name] = app_vars_cache[var_name]
                    else:
                        print(
                            f"[WARNING] App variable '{var_name}' requested but not found in app."
                        )
                else:
                    # User provided their own custom mock data
                    final_variables[var_name] = custom_val

            try:
                if debug:
                    print(f"[DEBUG] Executing tool: {test_case.tool}")
                    print(f"[DEBUG] Tool ID: {tool_id}")
                    print(f"[DEBUG] Args: {test_case.args}")
                    print(f"[DEBUG] Variables: {final_variables}")

                tool_response = self.tools_client.execute_tool(
                    app_id=self.app_id,
                    tool_display_name=test_case.tool,
                    args=test_case.args,
                    variables=final_variables,
                )

                if debug:
                    print(f"[DEBUG] Tool Response: {tool_response}")

                errors = self.validate_tool_test(test_case, tool_response)
                status = "SUCCESS"
                if errors:
                    status = "FAILURE"

                print(f"{status}: {test_case.tool} --> {test_case.name}")
                if errors:
                    print(errors)

                results.append(
                    {
                        "test": test_case.name,
                        "tool": test_case.tool,
                        "status": status,
                        "errors": errors,
                        "response": tool_response,
                    }
                )

            except Exception as e:
                print(f"FAILURE: Exception {e}")
                results.append(
                    {
                        "test": test_case.name,
                        "tool": test_case.tool,
                        "status": "FAILURE",
                        "errors": [str(e)],
                    }
                )

            print("-" * 30)

        return results

    def run_guardrail_tests(
        self, df: pd.DataFrame, debug: bool = False, console_logging: bool = False
    ) -> pd.DataFrame:
        """Runs guardrail evaluation tests from a pandas DataFrame.

        Args:
            df: Pandas DataFrame containing the test cases.
            debug: Whether to print debug information.
            console_logging: Whether to print a summarized output to console.

        Returns:
            A new pandas DataFrame with test results appended as columns.
        """
        # Validate that essential columns exist
        required_cols = ["user_input"]
        for col in required_cols:
            if col not in df.columns:
                raise ValueError(f"Required column '{col}' not found in DataFrame.")

        sessions_client = Sessions(app_id=self.app_id)

        # Try to get the app display name and configured model
        app_display_name = "Unknown App"
        configured_model = "Unknown Model"
        try:
            apps_client = Apps(
                project_id=self._get_project_id(self.app_id),
                location=self._get_location(self.app_id),
            )
            app_obj = apps_client.get_app(self.app_id)
            app_display_name = app_obj.display_name

            # Default to the app model setting
            configured_model = app_obj.model_settings.model

            # Check if root agent overrides the app model setting
            root_agent = self.agents_client.get_agent(app_obj.root_agent)
            if (
                hasattr(root_agent, "model_settings")
                and root_agent.model_settings.model
            ):
                configured_model = root_agent.model_settings.model

        except Exception as e:
            logger.warning(
                f"Could not retrieve app display name or model for {self.app_id}: {e}"
            )

        results = []
        for index, row in tqdm(
            df.iterrows(), total=len(df), desc="Running Guardrail Tests"
        ):
            # Replace NaNs with None for Pydantic validation
            row_dict = {
                k: (v if pd.notna(v) else None) for k, v in row.to_dict().items()
            }

            # Use test_id for name if available
            if "test_id" in row_dict and row_dict["test_id"]:
                row_dict["name"] = str(row_dict["test_id"])
            elif "name" not in row_dict or not row_dict["name"]:
                row_dict["name"] = f"Test_{index}"

            try:
                test_case = GuardrailTestCase(**row_dict)
            except Exception as e:
                logger.error(f"Failed to parse row {index} into GuardrailTestCase: {e}")
                results.append({"pass": False, "error": str(e)})
                continue

            if debug:
                print(f"Running guardrail test: {test_case.name}")

            session_id = sessions_client.create_session_id()

            try:
                parts = session_id.split("/")
                project = parts[1]
                location = parts[3]
                session_uuid = parts[-1]
                session_id_link = f'=HYPERLINK("https://ccai.cloud.google.com/insights/projects/{project}/locations/{location}/quality/conversations/{session_uuid}", "{session_uuid}")'
            except Exception:
                session_id_link = session_id

            error_msg = None
            actual_triggered = False
            actual_guardrail_name = None
            actual_guardrail_type = None
            actual_reason = None
            latency_ms = None
            agent_response_text = ""

            try:
                # Execute user query
                start_time = time.perf_counter()
                res = sessions_client.run(
                    session_id=session_id,
                    text=test_case.user_input,
                    variables=test_case.variables,
                    restart_session=True,
                )
                latency_ms = round((time.perf_counter() - start_time) * 1000, 2)

                outputs = getattr(res, "outputs", [])
                agent_response_text = self.get_agent_text_from_outputs(outputs)

                for output in outputs:
                    diagnostic_info = getattr(output, "diagnostic_info", None)
                    if diagnostic_info and hasattr(diagnostic_info, "root_span"):
                        root_span = diagnostic_info.root_span

                        try:
                            # Safely unwrap the protobuf or dict trace
                            span_dict = (
                                MessageToDict(root_span._pb)
                                if hasattr(root_span, "_pb")
                                else MessageToDict(root_span)
                            )
                        except Exception:
                            span_dict = (
                                dict(root_span) if isinstance(root_span, dict) else {}
                            )

                        triggered_span = self._search_span_dict(span_dict)
                        if triggered_span:
                            actual_triggered = True
                            attrs = triggered_span.get("attributes", {})
                            actual_guardrail_name = attrs.get("name")
                            actual_guardrail_type = attrs.get(
                                "type",
                                attrs.get("guardrailType", attrs.get("guardrail_type")),
                            )
                            actual_reason = attrs.get("reason")
                            break  # Found the triggered guardrail

            except Exception as e:
                error_msg = str(e)
                logger.error(f"Error running session for test '{test_case.name}': {e}")

            passed = True

            has_expected_name = bool(
                test_case.expected_guardrail_name
                and test_case.expected_guardrail_name.strip()
                and test_case.expected_guardrail_name.lower() != "none"
            )
            has_expected_type = bool(
                test_case.expected_guardrail_type
                and test_case.expected_guardrail_type.strip()
                and test_case.expected_guardrail_type.lower() != "none"
            )
            expected_triggered = has_expected_name or has_expected_type

            error_details = []
            if error_msg:
                passed = False
                error_details.append(error_msg)
            elif expected_triggered != actual_triggered:
                passed = False
                error_details.append(
                    f"Expected trigger: {expected_triggered}, Actual trigger: {actual_triggered}"
                )
            elif actual_triggered and expected_triggered:
                if (
                    has_expected_name
                    and test_case.expected_guardrail_name != actual_guardrail_name
                ):
                    passed = False
                    error_details.append(
                        f"Expected guardrail name '{test_case.expected_guardrail_name}', but got '{actual_guardrail_name}'"
                    )

                if has_expected_type and actual_guardrail_type:
                    norm_expected = (
                        test_case.expected_guardrail_type.lower()
                        .replace(" ", "")
                        .replace("_", "")
                    )
                    norm_actual = (
                        actual_guardrail_type.lower().replace(" ", "").replace("_", "")
                    )

                    matched = False
                    if norm_expected in (
                        "promptguard",
                        "rules",
                        "llmpolicy",
                        "llmpromptsecurity",
                    ):
                        matched = norm_actual in ("llmpolicy", "llmpromptsecurity")
                    elif norm_expected in ("blocklist", "contentfilter"):
                        matched = norm_actual in ("blocklist", "contentfilter")
                    elif norm_expected in ("rai", "raisafety", "safety", "modelsafety"):
                        matched = norm_actual in ("raisafety", "safety", "modelsafety")
                    else:
                        matched = norm_expected == norm_actual

                    if not matched:
                        passed = False
                        error_details.append(
                            f"Expected guardrail type matching '{test_case.expected_guardrail_type}', but got '{actual_guardrail_type}'"
                        )

            results.append(
                {
                    "actual_triggered": actual_triggered,
                    "actual_guardrail_name": actual_guardrail_name,
                    "actual_guardrail_type": actual_guardrail_type,
                    "actual_reason": actual_reason,
                    "agent_response": agent_response_text,
                    "latency (ms)": latency_ms,
                    "Session ID link": session_id_link,
                    "error": error_msg,
                    "error_details": error_details,
                    "pass": passed,
                    "app_id": self.app_id,
                    "app_display_name": app_display_name,
                    "model": configured_model,
                }
            )

            if debug:
                print(f"  Passed: {passed}")
                if actual_triggered:
                    print(f"  Triggered: {actual_guardrail_name}")
                    print(f"  Reason: {str(actual_reason)[:100]}...")

        if console_logging:
            print("\n######## Test Results ########\n")
            passed_count = sum(1 for res in results if res["pass"])
            failed_count = len(results) - passed_count

            for i, res in enumerate(results):
                test_id = df.iloc[i].get("test_id", df.iloc[i].get("name", f"Test_{i}"))
                status = "SUCCESS" if res["pass"] else "FAILURE"
                print(f"{status}: {test_id}")
                if not res["pass"] and res.get("error_details"):
                    print(json.dumps(res["error_details"]))

            print(
                f"\n######## Summary ########\nTotal Tests: {len(results)} | Passed: {passed_count} | Failed: {failed_count}\n"
            )

        # Append results to the original dataframe
        results_df = pd.DataFrame(results)
        return pd.concat([df.reset_index(drop=True), results_df], axis=1)


# --- Testing Classes ---


class Operator(str, enum.Enum):
    EQUALS = "equals"
    CONTAINS = "contains"
    GREATER_THAN = "greater_than"
    LESS_THAN = "less_than"
    LENGTH_EQUALS = "length_equals"
    LENGTH_GREATER_THAN = "length_greater_than"
    LENGTH_LESS_THAN = "length_less_than"
    IS_NULL = "is_null"
    IS_NOT_NULL = "is_not_null"


class Expectation(BaseModel):
    path: str
    operator: Operator
    value: Optional[Any] = None


class GuardrailTestCase(BaseModel):
    name: str = "Guardrail Test"
    user_input: str
    variables: Annotated[
        Dict[str, Any], BeforeValidator(EvalUtils.parse_variables_input)
    ] = Field(default_factory=dict)
    expected_guardrail_name: Optional[str] = None
    expected_guardrail_type: Optional[str] = None
    expected_parameters: Optional[str] = None


class ToolTestCase(BaseModel):
    name: str
    tool: str

    # We wrap the type in Annotated to add the BeforeValidator
    args: Annotated[Dict[str, Any], BeforeValidator(EvalUtils.empty_to_dict)] = Field(
        default_factory=dict, validation_alias=AliasChoices("args", "agrs")
    )

    variables: Annotated[
        Dict[str, Any], BeforeValidator(EvalUtils.parse_variables_input)
    ] = Field(default_factory=dict)

    response_expectations: Annotated[
        List[Expectation], BeforeValidator(EvalUtils.empty_to_list)
    ] = Field(
        default_factory=list, validation_alias=AliasPath("expectations", "response")
    )

    variable_expectations: Annotated[
        List[Expectation], BeforeValidator(EvalUtils.empty_to_list)
    ] = Field(
        default_factory=list, validation_alias=AliasPath("expectations", "variables")
    )
